Facility Helpdesk — Design System Preview
=========================================
This package contains a single static HTML Design System preview you can open locally or deploy.

Files:
- index.html : Design system preview page

How to use:
- Open index.html in your browser.
- Or upload the zip to CodeSandbox (Import Project -> Upload ZIP).

Created by ChatGPT.
